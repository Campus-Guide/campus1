<?php

require_once('db.php');
//echo $_POST['name'],"<br>";

/*if (isset($_POST['btn_save']))
{
  $name = mysqli_real_escape_string($con,$_POST['name']);
  $bday=mysqli_real_escape_string($con,$_POST['birthday']);
  $gender = mysqli_real_escape_string($con,$_POST['gender']);
  $registration=mysqli_real_escape_string($con,$_POST['registration']);
  echo $name;
 if(empty($name) || empty($bday)||empty($gender)||empty($registration)) {
    echo "<script>alert('Please fill in all the details')</script>";
}
  else {
    $sql = "insert into users (name,birthday,gender,registartion)
     values ('$name','$bday','$gender','$registration')";
    $result = mysqli_query($con,$sql);
		if($result){
		echo "<script>data</script>";
		}
		else {
      echo "<script>alert ('Please check your Query')</script>";
    } 
	}
}*/

 $sql = "insert into users (name,birthday,gender,registration)
     values ('".$_POST['name']."','".$_POST['birthday']."','".$_POST['gender']."','".$_POST['registration']."')";
    $result = mysqli_query($con,$sql);

    if($result){
      echo"congrats <a href=\"no-pop-up registration.html\"> Click here</a>";
    }

    else{echo"failed";}

?>
    