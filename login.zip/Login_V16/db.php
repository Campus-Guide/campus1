<?php

$con = mysqli_connect('localhost','root','','campusguide');

if (!$con) {
	echo "Please check your Database connection";
}

?>
