<?php

require_once('db.php');

  if(isset($_POST['name'])) 
	   {
		 $name=$_POST['name'];
		  $registration=$_POST['registration'];

		  $sql= "select name,registration from users where name='$name' AND registration='$registration' " ;
		     
		    if( $result=mysqli_query($con,$sql)  ){
	         $row=mysqli_num_rows($result);
	         if($row == 1) {

			    echo "you have successfuly logged in<br>
			    click <a href=\"no-pop-up registration.html\">here</a>
			    ";
			    exit();
	  
	    }
	    else {echo "string";}
        }
		    else{

		      echo "<script>alert('Please enter correct data!')</script>". mysqli_error($con);
		      exit();
		    }
	  }

	  else{
	  	echo"mysqli_error()";
	  }
 ?>